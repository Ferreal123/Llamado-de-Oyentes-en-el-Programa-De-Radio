# Pedidos de Temas Musicales en el Programa Dulce Compañia
Guardar en un archivo de Datos  los  datos de los  oyentes que nos soliciten  temas musicales.  Estos datos tienen que estar comprendidos por : -usuario
- lOCALIDAD 
- GENERO MUSICAL 
-   Tema
-  Social media  


Para el campo de Localidad,  Deberiamos traer una lista de localidades  desde un archivo de datos, DE QUE NO SE ENCUENTRE LA LOCALIDAD  SE PODRA AGREGAR.  
Para el campo de Red Social  tendre en el sistema las redes sociales que manejamos  y elegiremos entre ellas.
Como funcionalidad extra deberia saber las  cantidad de veces que se comunico cada usuario.
